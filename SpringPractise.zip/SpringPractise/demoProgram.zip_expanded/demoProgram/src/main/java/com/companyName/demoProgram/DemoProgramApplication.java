package com.companyName.demoProgram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DemoProgramApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context =SpringApplication.run(DemoProgramApplication.class, args);
		Machine a= context.getBean(Machine.class);
		
		a.start();
		System.out.println("it's working");
	}

}
