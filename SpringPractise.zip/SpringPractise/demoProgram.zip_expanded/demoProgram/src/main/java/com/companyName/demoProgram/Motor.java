package com.companyName.demoProgram;

public class Motor {

	private int motorId;
	private String motorHp;
	private String gearRatio;
	public int getMotorId() {
		return motorId;
	}
	public void setMotorId(int motorId) {
		this.motorId = motorId;
	}
	public String getMotorHp() {
		return motorHp;
	}
	public void setMotorHp(String motorHp) {
		this.motorHp = motorHp;
	}
	public String getGearRatio() {
		return gearRatio;
	}
	public void setGearRatio(String gearRatio) {
		this.gearRatio = gearRatio;
	}
	
	
}
