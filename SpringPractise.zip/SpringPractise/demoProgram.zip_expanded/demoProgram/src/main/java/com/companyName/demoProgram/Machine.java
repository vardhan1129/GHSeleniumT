package com.companyName.demoProgram;

import org.springframework.stereotype.Component;

@Component
public class Machine {

	private int mId;
	private String name;
	public int getmId() {
		return mId;
	}
	public void setmId(int mId) {
		this.mId = mId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public void start() {
		System.out.println("rev.....");
	}
}
