package com.companyName.demoProgram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProgramApplicationTests {

	@Test
	void contextLoads() {
	}

}
